package com.example.migrator;

import com.example.migrator.service.DataMigratorService;
import com.example.migrator.service.SchemaReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
public class MigrationRunner implements CommandLineRunner {

    @Autowired
    private SchemaReaderService schemaReaderService;
    @Autowired
    private DataMigratorService dataMigratorService;

    @Override
    public void run(String... args) {
        List<String> include = Arrays.asList(System.getProperty("include","").split(","));
        List<String> exclude = Arrays.asList(System.getProperty("exclude","").split(","));
        if (include.size()==1 && include.get(0).isEmpty()) include = Collections.emptyList();
        if (exclude.size()==1 && exclude.get(0).isEmpty()) exclude = Collections.emptyList();
        List<String> tables = schemaReaderService.getTableNames("YOUR_SCHEMA", include, exclude);
        dataMigratorService.migrateTables(tables);
    }
}
