package com.example.migrator.translator;

import java.util.HashMap;
import java.util.Map;

public class OracleToPostgresTypeTranslator {

    private static final Map<String, String> TYPE_MAPPING = new HashMap<>();

    static {
        TYPE_MAPPING.put("VARCHAR2", "VARCHAR");
        TYPE_MAPPING.put("NUMBER", "NUMERIC");
        TYPE_MAPPING.put("DATE", "TIMESTAMP");
        TYPE_MAPPING.put("CLOB", "TEXT");
        TYPE_MAPPING.put("BLOB", "BYTEA");
    }

    public static String translate(String oracleType) {
        return TYPE_MAPPING.getOrDefault(oracleType.toUpperCase(), oracleType);
    }
}
