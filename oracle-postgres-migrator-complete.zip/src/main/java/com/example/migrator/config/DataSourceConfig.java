package com.example.migrator.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfig {

    @Value("${oracle.url}")
    private String oracleUrl;
    @Value("${oracle.username}")
    private String oracleUser;
    @Value("${oracle.password}")
    private String oraclePass;

    @Value("${postgres.url}")
    private String pgUrl;
    @Value("${postgres.username}")
    private String pgUser;
    @Value("${postgres.password}")
    private String pgPass;

    @Bean
    @Primary
    public DataSource oracleDataSource() {
        return DataSourceBuilder.create()
                .url(oracleUrl)
                .username(oracleUser)
                .password(oraclePass)
                .driverClassName("oracle.jdbc.OracleDriver")
                .build();
    }

    @Bean
    public DataSource postgresDataSource() {
        return DataSourceBuilder.create()
                .url(pgUrl)
                .username(pgUser)
                .password(pgPass)
                .driverClassName("org.postgresql.Driver")
                .build();
    }
}
