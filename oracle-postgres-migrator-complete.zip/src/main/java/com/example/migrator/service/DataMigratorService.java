package com.example.migrator.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Service
public class DataMigratorService {

    private final DataSource oracleDataSource;
    private final DataSource postgresDataSource;

    public DataMigratorService(@Qualifier("oracleDataSource") DataSource oracleDataSource,
                               @Qualifier("postgresDataSource") DataSource postgresDataSource) {
        this.oracleDataSource = oracleDataSource;
        this.postgresDataSource = postgresDataSource;
    }

    public void migrateTables(List<String> tables) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        tables.forEach(table -> executor.submit(() -> {
            if (!isAlreadyMigrated(table)) {
                boolean success = migrateTable(table);
                recordAudit(table, success ? "COMPLETED" : "FAILED");
            } else {
                System.out.println("Skipping already migrated: " + table);
            }
        }));
        executor.shutdown();
    }

    private boolean migrateTable(String table) {
        try (Connection o = oracleDataSource.getConnection();
             Connection p = postgresDataSource.getConnection();
             Statement s = o.createStatement();
             ResultSet rs = s.executeQuery("SELECT * FROM " + table)) {

            ResultSetMetaData m = rs.getMetaData();
            int cols = m.getColumnCount();
            StringBuilder ph = new StringBuilder("?");
            for (int i=1;i<cols;i++) ph.append(",?");
            PreparedStatement ps = p.prepareStatement("INSERT INTO " + table + " VALUES (" + ph + ")");
            while (rs.next()) {
                for (int i=1;i<=cols;i++) ps.setObject(i, rs.getObject(i));
                ps.addBatch();
            }
            ps.executeBatch();
            return true;
        } catch (Exception e) {
            System.err.println("Error migrate " + table + ": " + e.getMessage());
            return false;
        }
    }

    private void recordAudit(String table, String status) {
        try (Connection c = postgresDataSource.getConnection();
             PreparedStatement ps = c.prepareStatement(
                 "INSERT INTO migration_audit(table_name,status) VALUES(?,?) ON CONFLICT(table_name) DO UPDATE SET status=EXCLUDED.status, last_updated=CURRENT_TIMESTAMP")) {
            ps.setString(1, table);
            ps.setString(2, status);
            ps.executeUpdate();
        } catch (Exception e) {
            System.err.println("Audit fail " + table + ": " + e.getMessage());
        }
    }

    private boolean isAlreadyMigrated(String table) {
        try (Connection c = postgresDataSource.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT 1 FROM migration_audit WHERE table_name=? AND status='COMPLETED'")) {
            ps.setString(1, table);
            return ps.executeQuery().next();
        } catch (Exception e) {
            return false;
        }
    }
}
