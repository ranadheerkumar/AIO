package com.example.migrator.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Service
public class SchemaReaderService {

    private final DataSource oracleDataSource;

    public SchemaReaderService(@Qualifier("oracleDataSource") DataSource oracleDataSource) {
        this.oracleDataSource = oracleDataSource;
    }

    public List<String> getTableNames(String schema, List<String> includeTables, List<String> excludeTables) {
        List<String> tables = new ArrayList<>();
        try (Connection conn = oracleDataSource.getConnection()) {
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet rs = metaData.getTables(null, schema.toUpperCase(), "%", new String[]{"TABLE"});
            while (rs.next()) {
                String tableName = rs.getString("TABLE_NAME");
                if ((includeTables.isEmpty() || includeTables.contains(tableName)) &&
                    (excludeTables.isEmpty() || !excludeTables.contains(tableName))) {
                    tables.add(tableName);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tables;
    }
}
