package com.example.migrator.service;

import com.example.migrator.translator.OracleToPostgresTypeTranslator;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.StringJoiner;

@Service
public class DDLGeneratorService {

    private final DataSource oracleDataSource;

    public DDLGeneratorService(@Qualifier("oracleDataSource") DataSource oracleDataSource) {
        this.oracleDataSource = oracleDataSource;
    }

    public String generateCreateTableDDL(String tableName) {
        StringBuilder ddl = new StringBuilder("CREATE TABLE " + tableName + " (\n");
        try (Connection conn = oracleDataSource.getConnection()) {
            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet columns = metaData.getColumns(null, null, tableName, null);
            StringJoiner joiner = new StringJoiner(",\n");
            while (columns.next()) {
                String colName = columns.getString("COLUMN_NAME");
                String colType = columns.getString("TYPE_NAME");
                int size = columns.getInt("COLUMN_SIZE");
                String pgType = OracleToPostgresTypeTranslator.translate(colType);
                joiner.add("  " + colName + " " + pgType + (pgType.equals("VARCHAR") ? "(" + size + ")" : ""));
            }
            ddl.append(joiner.toString()).append("\n);");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ddl.toString();
    }
}
