package com.example.migrator.steps;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

@SpringBootTest
public class MigrationSteps {

    @Autowired private DataSource oracleDataSource;
    @Autowired private DataSource postgresDataSource;
    private String table; private int oCount; private int pCount;

    @When("I compare the row count of table {string}")
    public void compare(String t) throws Exception {
        this.table=t;
        try (Connection c=oracleDataSource.getConnection();
             Statement s=c.createStatement();
             ResultSet r=s.executeQuery("SELECT COUNT(*) FROM "+t)) {r.next();oCount=r.getInt(1);}
        try (Connection c=postgresDataSource.getConnection();
             Statement s=c.createStatement();
             ResultSet r=s.executeQuery("SELECT COUNT(*) FROM "+t)) {r.next();pCount=r.getInt(1);}
    }

    @Then("both tables should have the same number of rows")
    public void validate(){Assert.assertEquals("Row count mismatch "+table,oCount,pCount);}
}
