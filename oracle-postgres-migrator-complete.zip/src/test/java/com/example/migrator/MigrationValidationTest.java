package com.example.migrator;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features",
    glue = "com.example.migrator.steps",
    plugin = {"pretty","html:target/cucumber-report.html","summary"},
    publish = true
)
public class MigrationValidationTest {}
